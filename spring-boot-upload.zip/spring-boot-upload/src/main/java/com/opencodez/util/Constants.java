package com.opencodez.util;

public class Constants {
	
	public static final String UPLOAD_LOCATION = "C:\\java-exec\\upload-dir\\";

}
